﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Reflection;
using System.IO;
using log4net;

namespace POSH_sharp.sys
{
    public class MobileControl : AssemblyControl
    {
        int agentId = 0;
        protected Stream [] action_plans;
        protected Stream initFile;
        protected Behaviour[] behaviours;
                

        internal MobileControl() : base()
        {
        }


        /// <summary>
        /// Returns a sequence of classes, containing all behaviour classes that
        /// are available in a particular library.
        /// 
        /// The method searches the behaviour subclasses by attempting to import
        /// all file in the library ending in .dll, except for the WORLDSCRIPT, and
        /// search through all classes they contain to see if they are derived from
        /// any behaviour class.
        /// 
        /// If a log object is given, then logging output at the debug level is
        /// produced.
        /// </summary>
        /// <param name="lib">Name of the library to find the classes for</param>
        /// <param name="log">A log object</param>
        /// <returns>The dictionary containing the Assembly dll name and the included Behaviour classes</returns>
        public Dictionary<string,List<Type>> getBehaviours(string lib, ILog log=null)
        {
            // get list of python files is behaviour library
            if (log is ILog)
                log.Debug("Scanning library "+lib+" for behaviour classes");

            Dictionary<string,List<Type>> modules=new Dictionary<string,List<Type>>();
 
            Assembly a = GetAssembly(lib);
            foreach(Type t in a.GetTypes())
                if (t.IsClass && t.IsSubclassOf(typeof(POSH_sharp.sys.Behaviour)) && (this.worldScript == null || t.Name != this.worldScript.Second))
                    if (!modules.ContainsKey(a.Location))
                        modules.Add(a.Location, new List<Type> { t });
                    else
                        modules[a.Location].Add(t);
            

            return ( modules.Count > 0 ) ? modules : null;
        }

        new public StreamReader getAgentInitFileStream(string agentsInitFile)
        {
            if (this.initFile is Stream && this.initFile.CanRead)
                return new StreamReader(this.initFile);
            
            return null;
            
        }

        new public StreamReader getAgentInitFileStream(string assembly, string agentsInitFile)
        {
            return getAgentInitFileStream(agentsInitFile);
        }
    }




}
